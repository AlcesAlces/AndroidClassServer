var app = require('express')();

// set the view engine to ejs
app.set('view engine', 'ejs');

var io = require('socket.io').listen(80);
var mongodb = require('mongodb');

var MongoClient = mongodb.MongoClient;

app.get('/', function(req,res)
{
	var drinks = [
	{name: 'Beer', drunkness: 1},
	{name: 'Martini', drunkness: 5},
	{name: 'Straight ethanol', drunkness: 10}
	];
	
	var tagline = 'Example of variable binding pre-compile time code.';
	
	res.render('pages/index', 
	{
		drinks: drinks,
		tagline: tagline
	});
});

// index page 
app.get('/', function(req, res) {
	res.render('pages/index');
});

// about page 
app.get('/about', function(req, res) {
	res.render('pages/about');
});

console.log('Server is listening for pages on 3000');
app.listen(3000);

//http.listen(3000, function()
//{
//	console.log('Website listening on *:3000');
//});

//Logic to handle all direct connections.
io.sockets.on('connection', function (socket) {

	//User obtains connection, a user is NOT authenticated at this point.
	console.log('User connection obatined.');
	
	//Can use this variable to determine who is authenticated.
	var authenticated = 0;
	
	//Verify the user's credentials. Doesn't do much right now, just make sure that the
	//username exists.
	socket.on('authenticate', function(authString)
	{	
		
		MongoClient.connect('mongodb://alces2:stimperman@ds045531.mongolab.com:45531/alces', function(err,db)
		{
			if(err)
			{
				console.log('Database error');
			}
			
			else
			{
				console.log(authString.name +' is attempting to auth.');
				//Should be able to swap out this mongo connection for any other kind of DB.
				var collection = db.collection('usersAndroid');
				
				collection.findOne({name: authString.name}, function(err, result)
				{
					if(err)
					{
						console.log(err);
					}
					
					else if(!result)
					{
						//User name does not exist in the database.
						socket.emit('disconnect','Your credentials have been rejected. Incorrect user name.');
					}
					
					//User is found in the log, do auth.
					else
					{
						console.log('Found user: ' + result.name + '. Doing Auth');
						
						//Basic auth.
						if(result.password == authString.pass)
						{
							console.log('User ' + authString.name + ' has been authorized');
							socket.emit('authenticate', 'Authentication string goes here!');
							authenticated = 1;
						}
						
						else
						{
							console.log('User ' + authString.name + ' has been rejected for incorrect password');
						}
					}
				});
			}
		});
	});
	
	//Creates a user in the database
	//currently not secure.
	socket.on('create', function(createString)
	{
		//var splitString = createString.split(";");
		//var userToAdd = {name: splitString[0], password: splitString[1]};
		
		MongoClient.connect('mongodb://alces2:stimperman@ds045531.mongolab.com:45531/alces', function(err,db)
		{
			if(err)
			{
				console.log('Database error');
			}
			
			else
			{
				console.log('Connection made with MongoDB user server');
				var collection = db.collection('usersAndroid');
				
				collection.findOne({name: createString.name}, function(err, result)
				{
					if(err)
					{
						console.log(err);
					}
					
					else if(!result)
					{
						collection.insert(createString, function(err,result)
						{
							if(err)
							{
								console.log(err);
							}
							else
							{
								console.log('Inserted new user into the database.' + createString.name);
								socket.emit('createsuccess','User created successfully');
							}
						});
					}
				});
				
			}
		});
		
	});
	
	socket.on('exit', function (name)
	{
		if(authenticated == 0)
		{
			console.log(name, ' has disconected.');
		}
	});
});